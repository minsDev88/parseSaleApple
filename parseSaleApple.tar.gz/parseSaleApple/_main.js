var fs = require('fs');
var csv = require('csv');

var saleData = {};

var options = {
	username : 'khj873@uangel.com',
	password : 'Uangel2012',
	vndnumber : '80081919'
}

var yesterDayStr = '';

fs.readFile(__dirname + '/filter.dat', 'utf8', function(error, data){
	console.log("Write Sale Report Apple", new Date() );

	getReport(data, parseSaleCSV);

});

var getReport = function(filterData, callback){

	var ingest = require (__dirname + '/lib/nodeingest').create(options);

	var tmpDate = new Date();
	var yesterDay = new Date(new Date( tmpDate.getFullYear() + '-' + (tmpDate.getMonth() + 1 ) + '-' + ( tmpDate.getDate() ) + ' 00:00:00') - 1 - 1000*60*60*24);
	yesterDayStr = yesterDay.getFullYear();
	yesterDayStr += '' + ( ( yesterDay.getMonth() + 1 < 10 ) ? '0' : '' ) + (yesterDay.getMonth() + 1);
	yesterDayStr += '' + yesterDay.getDate();

	console.log( yesterDayStr);

	var fetch_options = {
		typeofreport : 'Sales',
		datetype : 'Daily',
		reporttype : 'Summary',
		// reportdate : '20130818'
		reportdate : yesterDayStr
	};

	ingest.fetch( fetch_options, function( error, report ) {
		if( error ){
			console.log(error);
		} else {
			console.log('Success Get Report');
			callback(filterData, report);
		}
	});

}

var parseSaleCSV = function(filterData, report){
	// console.log(report);
	
	saleData = JSON.parse(filterData);
	for( var i = 0; i < report.length; i++ ){

		var info = {}
		info.parent_Identifier = report[i][ 'Parent Identifier' ];
		info.sku = report[i][ 'SKU' ];
		info.product_Type_Identifier = report[i][ 'Product Type Identifier' ];
		info.currency = report[i][ 'Customer Currency' ];

		var price = Number( report[i][ 'Customer Price' ].replace(',', '' ) );
		info.money = info.currency === 'KRW' ? price : 
					info.currency === 'USD' ? price * 1100 : 
					info.currency === 'JPY' ? price * 11 : 
					info.currency === 'GBP' ? price * 1700 :
					info.currency === 'EUR' ? price * 1700 :
					info.currency === 'CAD' ? price * 1000 : 
					info.currency === 'BRL' ? price * 500 :
					info.currency === 'NZD' ? price * 900 :
					info.currency === 'AUD' ? price * 1100 :
					info.currency === 'TWD' ? price * 37 : 
					price;



		// Install App or Paid App 
		if( (info.product_Type_Identifier === '1' 
			|| info.product_Type_Identifier === '1F') 
			&& typeof saleData[ info.sku ] !== 'undefined' )
		{

			saleData[ info.sku ].installCount = saleData[ info.sku ].installCount || 0;
			saleData[ info.sku ].installCount += 1;

			if( info.money !== 0 ){
				saleData[ info.sku ].money = saleData[ info.sku ].money || 0;
				saleData[ info.sku ].count = saleData[ info.sku ].count || 0;
				saleData[ info.sku ].money += info.money;
				saleData[ info.sku ].count += 1;
			}
		} 
		// InApp
		else if( info.product_Type_Identifier === 'IA1' 
			&& typeof saleData[ info.parent_Identifier ] !== 'undefined' 
			&& typeof saleData[ info.parent_Identifier ][ info.sku ] !== 'undefined' )
		{
			saleData[ info.parent_Identifier ][ info.sku ].count = 	saleData[ info.parent_Identifier ][ info.sku ].count || 0;
			saleData[ info.parent_Identifier ][ info.sku ].count += 1;
			saleData[ info.parent_Identifier ][ info.sku ].money = saleData[ info.parent_Identifier ][ info.sku ].money || 0;
			saleData[ info.parent_Identifier ][ info.sku ].money += info.money;
		}
	}

	saveReportToCSV(saleData);

};

var saveReportToCSV = function(saleData){
	var data = 'ProductID,SKUID,Charged-Refund-Count,sum,install-Count\n';
	var installData = '';

	for( var i in saleData ){
		// Paid App
		if( typeof saleData[ i ].count !== 'undefined' ){
			data += i + ',';
			data += ',';
			data += ( typeof saleData[ i ].count === 'undefined' || saleData[ i ].count === 0 ) ? ',' : saleData[ i ].count + ',';
			data += ( typeof saleData[ i ].money === 'undefined' || saleData[ i ].money === 0 ) ? ',' : saleData[ i ].money + ',';
			data += '\n';
		} 
		// InApp
		else {
			for( var j in saleData[ i ] ){
				if( j !== 'installCount' ){ 
					data += j + ','; 
					data += i + ',';
					data += ( typeof saleData[ i ][ j ].count === 'undefined' || saleData[i][j].count === 0 ) ? ',' : saleData[i][j].count + ',';
					data += ( typeof saleData[ i ][ j ].money === 'undefined' || saleData[i][j].money === 0 ) ? ',' : saleData[i][j].money + ',';
					data += '\n';
				}
			}
		}
		// Install App
		if( typeof saleData[ i ].installCount !== 'undefined' ){
			installData += i + ',,,,';
			installData += saleData[i].installCount;
			installData += '\n';
		} 
	}

	data += '\n\n' + installData;


	var fileName = __dirname + "/../../tomcat6.0.35/webapps/webdav/tomo/analytics/apple/" + yesterDayStr + '.csv';
	//var fileName = "./output/" + yesterDayStr + '.csv';
	fs.writeFile( fileName, data, function(err) {
		if( err ){
			throw err;
			console.log(err);
		} else {
			console.log( "Create CSV File" );
		}
	});
}

var getYearMM = function(){
	var now = new Date();
	var yearMM = now.getFullYear() + '';
	var month = now.getMonth() + 1;
	month = ( month < 10 ? '0' : '' ) + month;
	yearMM = yearMM + month;
	return yearMM;
};


